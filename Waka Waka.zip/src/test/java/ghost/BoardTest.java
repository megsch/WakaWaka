package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class BoardTest {

    private static Board b;

    @BeforeEach
    public void constructor() {
        b = new Board("src/test/resources/map3.txt", null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, new long[] {1, 1}, 3, 1, 1);
    }

    @Test
    public void getBoardFromFileTest() {
        b.getBoardFromFile("src/test/resources/map3.txt");   

        // Check size of Character array
        assertEquals(36, b.getBoard().length);
        assertEquals(28, b.getBoard()[0].length);
        
        assertEquals('1', b.getBoard()[17][0]);
        assertEquals('2', b.getBoard()[17][1]);
        assertEquals('3', b.getBoard()[17][2]);
        assertEquals('4', b.getBoard()[17][3]);
        assertEquals('5', b.getBoard()[17][4]);
        assertEquals('6', b.getBoard()[17][5]);
        assertEquals('7', b.getBoard()[17][6]);
        assertEquals('8', b.getBoard()[17][7]);

        java.lang.Character[][] result = b.getBoardFromFile("doesn'texist.txt");
        assertNull(result);


    }

    @Test
    public void createItemsTest() {
        b.createItems();
        
        // Check the size of different lists of objects
        assertEquals(36, b.getItems().length);
        assertEquals(28, b.getItems()[0].length);
        assertEquals(6, b.getWalls().size());
        assertEquals(1, b.getFruits().size());
        assertEquals(1, b.getSuperfruits().size());
        assertNotNull(b.getWaka());
        assertEquals(4, b.getGhosts().size());
    }

    @Test
    public void getLivesTest() {
        b.getLives();

        // Check size of list
        assertEquals(3, b.getLifes().size());

        for (Life l : b.getLifes()) {
            assertNotNull(l);
        }
    }

    @Test
    public void setupTest() {
        b.setup();

        // Check the size of different lists of objects
        assertEquals(36, b.getItems().length);
        assertEquals(28, b.getItems()[0].length);
        assertEquals(6, b.getWalls().size());
        assertEquals(1, b.getFruits().size());
        assertEquals(1, b.getSuperfruits().size());
        assertNotNull(b.getWaka());
        assertEquals(4, b.getGhosts().size());

        // Check size of list
        assertEquals(3, b.getLifes().size());

        for (Life l : b.getLifes()) {
            assertNotNull(l);
        }
    }

    @Test
    public void removeFruitTest() {
        b.setup();
        
        // Waka isn't touching any fruit
        b.removeFruits();

        // Check no fruit has been removed
        assertEquals(1, b.getFruits().size());
        assertEquals(1, b.getSuperfruits().size());


        // Move waka to fruit
        b.getWaka().left();

        for (int i = 0; i < 16; i++) {
            b.getWaka().move(b.getItems());
        }
        b.removeFruits();
        assertEquals(1, b.getFruits().size());
        assertEquals(0, b.getSuperfruits().size());


        // Move waka to superfruit
        for (int i = 0; i < 16; i++) {
            b.getWaka().move(b.getItems());
        }
        b.removeFruits();
        assertEquals(0, b.getFruits().size());
        assertEquals(0, b.getSuperfruits().size());

        
        // Move waka to wall cell
        for (int i = 0; i < 16; i++) {
            b.getWaka().move(b.getItems());
        }
        b.removeFruits();
        assertEquals(0, b.getFruits().size());
        assertEquals(0, b.getSuperfruits().size());
    }

    @Test
    public void checkWinTest1() {
        // Explore null options
        b.setup();

        assertNull(b.checkWin());

        // Get rid of superfruit
        for (int i = 0; i < 16; i++) {
            b.getWaka().move(b.getItems());
        }
        b.removeFruits();
        assertNull(b.checkWin());


        // Have only superfruit
        Superfruit tmp = new Superfruit(null, 17, 8);
        b.getItems()[17][7] = tmp;
        b.getSuperfruits().add(tmp);
        for (int i = 0; i < 16; i++) {
            b.getWaka().move(b.getItems());
        }
        b.removeFruits();
        assertNull(b.checkWin());
    }

    @Test
    public void checkWinTest2() {
        // Explore lose options
        b.setup();
        b.getLifes().clear();
        assertFalse(b.checkWin());
    }

    @Test
    public void checkWinTest3() {
        // Explore right options
        b.setup();

        b.getFruits().clear();
        b.getSuperfruits().clear();
        assertTrue(b.checkWin());

    }

    @Test
    public void changeDebugTest() {
        // Turn on
        b.changeDebugMode();
        assertTrue(b.getDebugState());

        // Toggle debug before buffer is done
        b.changeDebugMode();
        assertTrue(b.getDebugState());

        // Turn off debug
        for (int i = 0; i < 20; i++) {
            b.minusDebugBuffer();
        }
        b.changeDebugMode();
        assertFalse(b.getDebugState());
    }

    @Test
    public void resetBoardTest() {
        b.setup();

        b.getFruits().clear();
        b.getSuperfruits().clear();
        b.getLifes().clear();
        b.getGhosts().clear();

        b.resetBoard();

        assertEquals(1, b.getFruits().size());
        assertEquals(1, b.getSuperfruits().size());
        assertEquals(3, b.getLifes().size());
        assertEquals(4, b.getGhosts().size());
    }

    @Test
    public void checkCollisionTest() {
        // Waka and ghost collide
        b.setup();
        assertTrue(b.checkCollision(b.getGhosts().get(0)));
        for (int i = 1; i < b.getGhosts().size(); i++) {
            assertFalse(b.checkCollision(b.getGhosts().get(i)));
        }

        
        // Waka and ghost don't collide
        // Waka is to the left of ghosts
        b.getWaka().left();
        for (int i = 0; i < 16; i++) {
            b.getWaka().move(b.getItems());
        }
        assertFalse(b.checkCollision(b.getGhosts().get(0)));


        // Waka is above ghost
        b.getWaka().up();
        for (int i = 0; i < 30; i++) {
            b.getWaka().move(b.getItems());
        }
        assertFalse(b.checkCollision(b.getGhosts().get(0)));


        // Waka is below ghost
        b.getWaka().down();
        for (int i = 0; i < 60; i++) {
            b.getWaka().move(b.getItems());
        }
        assertFalse(b.checkCollision(b.getGhosts().get(0)));


        // Waka is to the right of ghost
        b.getWaka().right();
        for (int i = 0; i < 80; i++) {
            b.getWaka().move(b.getItems());
        }
        b.getWaka().up();
        for (int i = 0; i < 30; i++) {
            b.getWaka().move(b.getItems());
        }
        assertFalse(b.checkCollision(b.getGhosts().get(0)));

    }

    @Test
    public void backToStartTest() {
        b.setup();
        // Move ghosts and waka out of position
        b.getWaka().up();
        for (int i = 0; i < 50; i++) {
            b.getWaka().move(b.getItems());
        }

        for (Ghost g : b.getGhosts()) {
            for (int i = 0; i < 50; i++) {
                g.tick(b.getItems(), b.getWaka(), null);
            }
        }

        // Reset position and check
        b.backToStart();

        // Check waka
        assertEquals(17, b.getWaka().getCell()[0]);
        assertEquals(8, b.getWaka().getCell()[1]);

        // Check ghosts
        int x = 17;
        int y = 9;
        for (Ghost g : b.getGhosts()) {
            assertEquals(x, g.getCell()[0]);
            assertEquals(y, g.getCell()[1]);
            y++;
        }
    }

    @Test
    public void screenCountTest() {
        b.setup();
        // turn on screen
        assertFalse(b.screenCount());

        for (int i = 0; i < 598; i++) {
            assertFalse(b.screenCount());
        }

        // Turn off screen
        assertTrue(b.screenCount());

    }

    @Test
    public void tickTest1() {
        // No win or lose
        b = new Board("src/test/resources/map2.txt", null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, new long[] {1, 1}, 3, 1, 1);
        b.setup();
        
        // Available chaser not removed, no collision
        b.tick(null);
        // Check position of waka
        assertEquals(307, b.getWaka().getCenterPoint()[0]);
        assertEquals(146, b.getWaka().getCenterPoint()[1]);
        // Check position of chaser
        assertEquals(274, b.getGhosts().get(0).getCenterPoint()[0]);
        assertEquals(147, b.getGhosts().get(0).getCenterPoint()[1]);


        // Chaser is removed
        b.getGhosts().get(0).remove();
        b.tick(null);
        // Check Position of waka
        assertEquals(307, b.getWaka().getCenterPoint()[0]);
        assertEquals(145, b.getWaka().getCenterPoint()[1]);


        // Check collisions
        b.getGhosts().get(0).replace();
        b.getWaka().up();
        for (int i = 0; i < 20; i++) {
            b.getWaka().move(b.getItems());
        }
        b.tick(null);
        // Check lives
        assertEquals(2, b.getLifes().size());
        // Check positions
        assertEquals(307, b.getWaka().getCenterPoint()[0]);
        assertEquals(147, b.getWaka().getCenterPoint()[1]);
        assertEquals(275, b.getGhosts().get(0).getCenterPoint()[0]);
        assertEquals(147, b.getGhosts().get(0).getCenterPoint()[1]);


        // Collision when ghost is frightened
        b.getGhosts().get(0).fright();
        b.getWaka().up();
        for (int i = 0; i < 20; i++) {
            b.getWaka().move(b.getItems());
        }
        b.tick(null);
        // Check lives
        assertEquals(2, b.getLifes().size());
        // Check positions
        assertEquals(286, b.getWaka().getCenterPoint()[0]);
        assertEquals(147, b.getWaka().getCenterPoint()[1]);
        // Check ghost
        assertTrue(b.getGhosts().get(0).isRemoved());

        
        // No ghosts
        b.getGhosts().clear();
        b.tick(null);
        assertEquals(285, b.getWaka().getCenterPoint()[0]);
        assertEquals(147, b.getWaka().getCenterPoint()[1]);


        // Ghost not chaser
        b.getGhosts().add(new Ambusher(null, null, 17, 9, 1, new int[] {0, 28}, 1, new long[] {1, 1}));
        b.backToStart();
        b.tick(null);
        // Check position of waka
        assertEquals(307, b.getWaka().getCenterPoint()[0]);
        assertEquals(146, b.getWaka().getCenterPoint()[1]);
        // Check position of ghost
        assertEquals(275, b.getGhosts().get(0).getCenterPoint()[0]);
        assertEquals(148, b.getGhosts().get(0).getCenterPoint()[1]);
    }

    @Test
    public void tickTest2() {
        // Win
        b = new Board("src/test/resources/map2.txt", null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, new long[] {1, 1}, 3, 1, 1);

        b.getFruits().clear();
        b.getSuperfruits().clear();
        b.tick(null);
        assertEquals(1, b.getScreenCount());

        // After 10 seconds reset board
        for (int i = 0; i < 598; i++) {
            b.tick(null);
        }

        b.tick(null);
        assertEquals(0, b.getScreenCount());
    }

    @Test
    public void tickTest3() {
        // Debug
        b = new Board("src/test/resources/map2.txt", null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, new long[] {1, 1}, 3, 1, 1);
        b.setup();

        b.changeDebugMode();
        b.tick(null);
        assertTrue(b.getDebugState());
        // Try to toggle before debug buffer is done
        b.changeDebugMode();
        b.tick(null);
        assertTrue(b.getDebugState());
        // Toggle debug when debug buffer is done
        for (int i = 0; i < 18; i++) {
            b.tick(null);
        }
        b.changeDebugMode();
        assertFalse(b.getDebugState());
    }
}