package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

import ghost.Ghost.GhostType;
import java.util.*;

class GhostTest {

    private static Chaser c;

    // Test the shared methods using Chaser

    @BeforeEach
    public void construct() {
        
        // app = new App("chaser.png", "frightened.png");
        c = new Chaser(null, null, 3, 3, 1, new int[] {0,0}, 1, new long[] {1,1});
    }

    @Test
    public void constructorTest() {
        // Test get constructors  
        assertNotNull(c);

        assertEquals(GhostType.CHASER, c.getType());

    }

    @Test
    public void frightenedTest() {
        assertFalse(c.getFrightened());

        c.fright();

        assertTrue(c.getFrightened());
        assertTrue(c.checkFrightened());
        
        int i = 0;
        while (i < 60) {
            c.checkFrightened();
            i++;
        }
        assertFalse(c.checkFrightened());
        
    }

    @Test
    public void removedTest() {
        assertFalse(c.isRemoved());
        c.remove();
        assertTrue(c.isRemoved());
        c.replace();
        assertFalse(c.isRemoved());
    }

    @Test
    public void modecountTest() {

        c.countMode();
        assertTrue(c.isScatter());

        int i = 0;
        while (i < 60) {
            c.countMode();
            i++;
        }

        assertFalse(c.isScatter());
        i = 0;
        while(i < 65) {
            c.countMode();
            i++;
        }

        assertTrue(c.isScatter());
    }


    @Test
    public void checkUpTest() {
        Item[][] boardObjects = new Item[36][28];
        Item wall = new Wall(null,0,3);
        Item fruit = new Fruit(null, 1, 3);
        Item superfruit = new Superfruit(null, 2, 3);
        boardObjects[0][3] = wall;
        boardObjects[1][3] = fruit;
        boardObjects[2][3] = superfruit;

        c.up();

        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
            assertTrue(c.checkUp(boardObjects));
        }

        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
        }
        assertFalse(c.checkUp(boardObjects));

        c.right();
        for (int i = 0; i < 10; i++) {
            c.move(boardObjects);
        }
        
        assertFalse(c.checkUp(boardObjects));
    }

    @Test
    public void checkDownTest() {
        Item[][] boardObjects = new Item[36][28];
        Item wall = new Wall(null,6,3);
        Item fruit = new Fruit(null, 5, 3);
        Item superfruit = new Superfruit(null, 4, 3);
        boardObjects[6][3] = wall;
        boardObjects[5][3] = fruit;
        boardObjects[4][3] = superfruit;

        c.down();
        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
            assertTrue(c.checkDown(boardObjects));
        }

        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
        }

        assertFalse(c.checkDown(boardObjects));

        c.right();
        for (int i = 0; i < 10; i++) {
            c.move(boardObjects);
        }
        
        assertFalse(c.checkDown(boardObjects));
    }

    @Test
    public void checkRightTest() {
        Item[][] boardObjects = new Item[36][28];
        Item wall = new Wall(null,3,6);
        Item fruit = new Fruit(null, 3, 5);
        Item superfruit = new Superfruit(null, 3, 4);
        boardObjects[3][6] = wall;
        boardObjects[3][5] = fruit;
        boardObjects[3][4] = superfruit;

        c.right();
        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
            assertTrue(c.checkRight(boardObjects));
        }

        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
        }
        assertFalse(c.checkRight(boardObjects));

        c.up();
        for (int i = 0; i < 10; i++) {
            c.move(boardObjects);
        }
        assertFalse(c.checkRight(boardObjects));
    }

    @Test
    public void checkLeftTest() {
        Item[][] boardObjects = new Item[36][28];
        Item wall = new Wall(null,3,0);
        Item fruit = new Fruit(null, 3, 1);
        Item superfruit = new Superfruit(null, 3, 2);
        boardObjects[3][0] = wall;
        boardObjects[3][1] = fruit;
        boardObjects[3][2] = superfruit;

        c.left();
        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
            assertTrue(c.checkLeft(boardObjects));
        }

        for (int i = 0; i < 16; i++) {
            c.move(boardObjects);
        }
        assertFalse(c.checkLeft(boardObjects));

        c.up();
        for (int i = 0; i < 10; i++) {
            c.move(boardObjects);
        }
        assertFalse(c.checkLeft(boardObjects));
    }

    @Test
    public void currentTargetTest() {

    }

    @Test
    public void backtrackVelocityTest() {
        c.down();
        assertEquals(Directions.UP, c.backtrackVelocityDirection());

        c.up();
        assertEquals(Directions.DOWN, c.backtrackVelocityDirection());

        c.right();
        assertEquals(Directions.LEFT, c.backtrackVelocityDirection());

        c.left();
        assertEquals(Directions.RIGHT, c.backtrackVelocityDirection());

        c.clearSpeed();
        assertNull(c.backtrackVelocityDirection());
    }

    @Test
    public void findPossibleMovesTest() {
        ArrayList<Directions> possibleMoves = new ArrayList<>();
        possibleMoves.add(Directions.UP);
        possibleMoves.add(Directions.DOWN);
        possibleMoves.add(Directions.LEFT);
        possibleMoves.add(Directions.RIGHT);
        
        Item[][] boardObjects = new Item[36][28];
        ArrayList<Directions> actual = c.findPossibleMoves(boardObjects);

        for (Directions d : possibleMoves) {
            assertTrue(actual.contains(d));
        }

        for (Directions d : actual) {
            assertTrue(possibleMoves.contains(d));
        }

        Item wall1 = new Wall(null, 2,3);
        Item wall2 = new Wall(null, 4,3);
        Item wall3 = new Wall(null, 3,2);
        Item wall4 = new Wall(null, 3,4);
        boardObjects[2][3] = wall1;
        boardObjects[4][3] = wall2;
        boardObjects[3][2] = wall3;
        boardObjects[3][4] = wall4;

        ArrayList<Directions> actualNone = c.findPossibleMoves(boardObjects);
        assertEquals(0, actualNone.size());

    }

    @Test
    public void findCurrentTarget() {
        c.countMode();
        int[] target = c.findCurrentTarget(null, null);
        assertEquals(0, target[0]);
        assertEquals(0, target[1]);

        target = c.getCurrentTarget();
        assertEquals(0, target[0]);
        assertEquals(0, target[1]);

    }

    @Test
    public void backToStartTest() {
        Item[][] boardObjects = new Item[36][28];
        c.right();
        c.move(boardObjects);
        c.fright();
        c.remove();

        c.backToStart();
        assertEquals(3, c.getCell()[0]);
        assertEquals(3, c.getCell()[1]);
        assertEquals(51, c.getCenterPoint()[0]);
        assertEquals(51, c.getCenterPoint()[1]);
        assertEquals(0, c.getdx());
        assertEquals(0, c.getdy());
        assertFalse(c.getFrightened());
        assertFalse(c.isRemoved());

    }

    @Test
    public void tickNotFrightTest() {
        Waka waka = new Waka(0,0, null, null, null, null, null, 1);
        
        // All moves possible
        Item[][] boardObjects = new Item[36][28];
        boardObjects[0][2] = new Wall(null, 0, 2);
        boardObjects[1][1] = new Wall(null, 1, 1);
        boardObjects[2][2] = new Wall(null, 2, 2);
        c = new Chaser(null, null, 1, 3, 1, new int[] {0,0}, 1, new long[] {1,1});

        int[] before = c.getCenterPoint();
        assertEquals(19, before[0]);
        assertEquals(51, before[1]);

        c.tick(boardObjects, waka, c);
        int[] actual = c.getCenterPoint();
        assertEquals(19, actual[0]);
        assertEquals(50, actual[1]);
        assertEquals(-1, c.getdy());
        assertEquals(0, c.getdx());

        for (int i = 0; i < 6; i++) {
            c.tick(boardObjects, waka, c);
        }

        // Check no backtrack
        assertEquals(-1, c.getdy());
        waka = new Waka(1,5, null, null, null, null, null, 1);
        c.tick(boardObjects, waka, c);
        assertEquals(-1, c.getdy());
        assertEquals(0, c.getdx());

        // Reach deadend and should backtrack
        for (int i = 0; i < 35; i++) {
            c.tick(boardObjects, waka, c);
        }
        assertEquals(1, c.getdy());
        assertEquals(0, c.getdx());


        // No moves possible
        boardObjects = new Item[36][28];
        c = new Chaser(null, null, 1, 3, 1, new int[] {0,0}, 1, new long[] {1,1});

        boardObjects[0][3] = new Wall(null, 0, 3);
        boardObjects[2][3] = new Wall(null, 2, 3);
        boardObjects[1][2] = new Wall(null, 1, 2);
        boardObjects[1][4] = new Wall(null, 1, 4);

        c.tick(boardObjects, waka, c);
        actual = c.getCenterPoint();
        assertEquals(19, actual[0]);
        assertEquals(51, actual[1]);
        assertEquals(0, c.getdy());
        assertEquals(0, c.getdy());
    }

    @Test
    public void tickFrightTest() {
        Waka waka = new Waka(0,0, null, null, null, null, null, 1);
        Item[][] boardObjects = new Item[36][28];

        c.fright();
        // Check for backtrack
        c.tick(boardObjects, waka, c);
        int firsty = c.getdy() * -1;
        int firstx = c.getdx() * -1;

        for (int i = 0; i < 30; i++) {
            c.tick(boardObjects, waka, c);
            if (firsty != 0)
            assertTrue(c.getdy() != firsty);
            if (firstx != 0)
            assertTrue(c.getdx() != firstx);
            firsty = c.getdy() * -1;
            firstx = c.getdx() * -1;
        }

        // Check speed when no moves
        boardObjects = new Item[36][28];
        c = new Chaser(null, null, 1, 3, 1, new int[] {0,0}, 1, new long[] {1,1});
        c.fright();

        boardObjects[0][3] = new Wall(null, 0, 3);
        boardObjects[2][3] = new Wall(null, 2, 3);
        boardObjects[1][2] = new Wall(null, 1, 2);
        boardObjects[1][4] = new Wall(null, 1, 4);

        c.tick(boardObjects, waka, c);
        assertEquals(0, c.getdx());
        assertEquals(0, c.getdy());
    }

    @Test
    public void tickBoarders() {
        Waka waka = new Waka(0,0, null, null, null, null, null, 1);
        Item[][] boardObjects = new Item[36][28];

        // Check top
        c = new Chaser(null, null, 0, 3, 1, new int[] {0,0}, 1, new long[] {1,1});
        c.tick(boardObjects, waka, c);
        assertTrue(c.getdx() != -1);

        // Check bottom
        c = new Chaser(null, null, 35, 3, 1, new int[] {0,0}, 1, new long[] {1,1});
        c.tick(boardObjects, waka, c);
        assertTrue(c.getdx() != 1);

        // Check left
        c = new Chaser(null, null, 3, 0, 1, new int[] {0,0}, 1, new long[] {1,1});
        c.tick(boardObjects, waka, c);
        assertTrue(c.getdy() != -1);


        // Check right
        c = new Chaser(null, null, 3, 27, 1, new int[] {0,0}, 1, new long[] {1,1});
        c.tick(boardObjects, waka, c);
        assertTrue(c.getdy() != 1);

    }  

}