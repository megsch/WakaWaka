package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ItemTest {

    @Test
    public void getAttributesTest() {
        Item item = new Fruit(null, 0, 0);
        
        assertEquals(0, item.getcell()[0]);
        assertEquals(0, item.getcell()[1]);

        assertEquals(0, item.getX());
        assertEquals(0, item.getY());

        assertEquals(8, item.getCenterPoint()[0]);
        assertEquals(8, item.getCenterPoint()[1]);
    }

    @Test
    public void LifeTest() {
        Life l = new Life(null, 0, 0);
        
        assertEquals(0, l.getcell()[0]);
        assertEquals(0, l.getcell()[1]);

        assertEquals(0, l.getX());
        assertEquals(0, l.getY());

        assertEquals(8, l.getCenterPoint()[0]);
        assertEquals(8, l.getCenterPoint()[1]);
    }
}