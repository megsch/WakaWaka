package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class IgnorantTest {

    public static Ignorant i;

    @BeforeEach
    public void construct() {
        i = new Ignorant(null, null, 3, 3, 1, new int[] {36, 0}, 1, new long[] {1, 1});
    }

    @Test
    public void updateTargetTest1() {
        // Waka is more than 8 away
        Waka w = new Waka(35, 27, null, null, null, null, null, 1);
        int[] target = i.updateTarget(w, null);
        assertEquals(35, target[0]);
        assertEquals(27, target[1]);
    }

    @Test
    public void updateTargetTest2() {
        // Waka is less than 8 away
        Waka w = new Waka(0, 0, null, null, null, null, null, 1);
        int[] target = i.updateTarget(w, null);
        assertEquals(36, target[0]);
        assertEquals(0, target[1]);
    }

    @Test
    public void updateTargetTest3() {
        // No waka
        int[] target = i.updateTarget(null, null);
        assertNull(target);
    }
}