package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class WhimTest {

    private static Whim w;

    @BeforeEach
    public void constructor() {
        w = new Whim(null, null, 5, 5, 1, new int[] {36, 28}, 1, new long[] {1, 1});
    }

    @Test
    public void updateTargetTest1() {
        Waka waka = new Waka(3,3, null, null, null, null, null, 1);
        
        // No chaser
        int[] target = w.updateTarget(waka, null);
        assertEquals(3, target[0]);
        assertEquals(3, target[1]);
    }

    @Test
    public void updateTargetTest2() {
        // No waka
        int[] target = w.updateTarget(null, null);
        assertNull(target);
    }

    @Test
    public void updateTargetTest3() {
        // Waka is above chaser
        Waka waka  = new Waka(3, 19, null, null, null, null, null, 1);
        Chaser chaser = new Chaser(null, null, 18, 19, 1, new int[] {0,0}, 1, new long[] {1,1});

        // Waka is going up
        waka.up();
        int[] target = w.updateTarget(waka, chaser);
        assertEquals(0, target[0]);
        assertEquals(19, target[1]);

        // Waka is going right
        waka.right();
        target = w.updateTarget(waka, chaser);
        assertEquals(0, target[0]);
        assertEquals(23, target[1]);

        // Waka is going down
        waka.down();
        target = w.updateTarget(waka, chaser);
        assertEquals(0, target[0]);
        assertEquals(19, target[1]);

        // Waka is going left
        waka.left();
        target = w.updateTarget(waka, chaser);
        assertEquals(0, target[0]);
        assertEquals(15, target[1]);

        // Waka is still
        waka.clearSpeed();
        target = w.updateTarget(waka, chaser);
        assertEquals(0, target[0]);
        assertEquals(19, target[1]);

    }

    @Test
    public void updateTargetTest4() {
        // Waka is below chaser
        Waka waka  = new Waka(18, 19, null, null, null, null, null, 1);
        Chaser chaser = new Chaser(null, null, 3, 19, 1, new int[] {0,0}, 1, new long[] {1,1});

        // Waka is going down
        waka.down();
        int[] target = w.updateTarget(waka, chaser);
        assertEquals(35, target[0]);
        assertEquals(19, target[1]);
    }

    @Test
    public void updateTargetTest5() {
        // Waka is to the right of chaser
        Waka waka  = new Waka(18, 19, null, null, null, null, null, 1);
        Chaser chaser = new Chaser(null, null, 18, 3, 1, new int[] {0,0}, 1, new long[] {1,1});

        // Waka is going right
        w.right();
        int[] target = w.updateTarget(waka, chaser);
        assertEquals(18, target[0]);
        assertEquals(27, target[1]);
    }

    @Test
    public void updateTargetTest6() {
        // Waka is to the left of chaser
        Waka waka  = new Waka(18, 3, null, null, null, null, null, 1);
        Chaser chaser = new Chaser(null, null, 18, 19, 1, new int[] {0,0}, 1, new long[] {1,1});

        // Waka is going left
        w.left();
        int[] target = w.updateTarget(waka, chaser);
        assertEquals(18, target[0]);
        assertEquals(0, target[1]);
    }

    @Test
    public void updateTargetTest7() {
        // Target is not outside of border
        Waka waka  = new Waka(18, 19, null, null, null, null, null, 1);
        Chaser chaser = new Chaser(null, null, 18, 20, 1, new int[] {0,0}, 1, new long[] {1,1});

        // Waka is going up
        waka.up();
        int[] target = w.updateTarget(waka, chaser);
        assertEquals(14, target[0]);
        assertEquals(18, target[1]);
    }
}