package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class WakaTest {

    private static Waka w;

    @BeforeEach
    public void construct() {
        w  = new Waka(3,3, null, null, null, null, null, 1);
    }

    @Test
    public void constructorTest() {
        assertNotNull(w);
        assertEquals(3, w.getCell()[0]);
        assertEquals(3, w.getCell()[1]);

    }
}