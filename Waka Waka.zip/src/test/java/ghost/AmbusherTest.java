package ghost;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class AmbusherTest {

    private static Ambusher a;

    @BeforeEach
    public void constructor() {
        a = new Ambusher(null, null, 3, 3, 1, new int[] {0, 28}, 1, new long[] {1, 1});
    }

    @Test
    public void updateTargetTest1() {
        // Target when waka is in the middle of the board

        Waka w = new Waka(5, 5, null, null, null, null, null, 1);

        // Waka is heading left
        w.left();
        int[] target = a.updateTarget(w, null);
        assertEquals(5, target[0]);
        assertEquals(1, target[1]);

        // Waka is heading right
        w.right();
        target = a.updateTarget(w, null);
        assertEquals(5, target[0]);
        assertEquals(10, target[1]);

        // Waka is heading up
        w.up();
        target = a.updateTarget(w, null);
        assertEquals(1, target[0]);
        assertEquals(5, target[1]);

        // waka is heading down
        w.down();
        target = a.updateTarget(w, null);
        assertEquals(10, target[0]);
        assertEquals(5, target[1]);

        // Waka isn't moving
        w.clearSpeed();
        target = a.updateTarget(w, null);
        assertEquals(5, target[0]); 
        assertEquals(5, target[1]);
    }

    @Test
    public void updateTargetTest2() {
        // Target when waka is on the boarder

        // When waka is facing up
        Waka w = new Waka(1, 5, null, null, null, null, null, 1);
        w.up();
        int[] target = a.updateTarget(w, null);
        assertEquals(0, target[0]);
        assertEquals(5, target[1]);

        // When waka is facing right
        w = new Waka(5, 26, null, null, null, null, null, 1);
        w.right();
        target = a.updateTarget(w, null);
        assertEquals(5, target[0]);
        assertEquals(27, target[1]);

        // When waka is facing down
        w = new Waka(34, 5, null, null, null, null, null, 1);
        w.down();
        target = a.updateTarget(w, null);
        assertEquals(35, target[0]);
        assertEquals(5, target[1]);

        // When waka is facing left
        w = new Waka(5, 1, null, null, null, null, null, 1);
        w.left();
        target = a.updateTarget(w, null);
        assertEquals(5, target[0]);
        assertEquals(0, target[1]);

    }
}