package ghost;

import processing.core.PImage;

public class Chaser extends Ghost {

    /**
     * Constructor for the Chaser
     * @param normal PImage for the ghost during chase and scatter
     * @param frightened PImage for the ghost when frightened
     * @param xspawn Pixel row position of the spawn location
     * @param yspawn Current column pixel position of the character, from the top left corner
     * @param speed The number of pixels it moves per frame
     * @param targetDefault Cell location of the ghost's default corner during scatter
     * @param frightenedLength Length of frighten time in frames
     * @param modeLength Time length of scatter and chase modes
     */
    public Chaser(PImage normal, PImage frightened, int xspawn, int yspawn, long speed, 
    int[]targetDefault, long frightenedLength, long[] modeLength) {
        super(normal, frightened, xspawn, yspawn, speed, targetDefault, frightenedLength, 
        modeLength, GhostType.CHASER);
    }

    /**
     * Updates target to be waka's position
     */
    public int[] updateTarget(Waka waka, Ghost chaser)  {
        if (waka == null) {
            return null;
        }
        return waka.getCell();
    }

}