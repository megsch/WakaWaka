package ghost;

enum Directions {
    RIGHT(0,2),
    LEFT(0,-1),
    UP(-1,0),
    DOWN(2,0);

    private final int x;
    private final int y;

    /**
     * The directions' relative x and y point from an arbitrary point
     * @param x relative x point from the arbitrary point
     * @param y relative y point from the arbitrary point
     */
    private Directions(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * From the given ghost's location, return the next x position in that direction
     * @param ghostPos
     * @return x position
     */
    public int getXPos(int[] ghostPos) {
        return ghostPos[0] + this.x;
    }

    /**
     * From the given ghost's location, return the next y position in that direction
     * @param ghostPos
     * @return y position
     */
    public int getYPos(int[] ghostPos) {
        return ghostPos[1] + this.y;
    }


}