package ghost;

import processing.core.PImage;

public class Wall extends Item {

    /**
     * Constructor for a wall
     * @param sprite PImage
     * @param xpos pixel position in a column
     * @param ypos pixel position in a row
     */
    public Wall(PImage sprite, int xpos, int ypos) {
        super(sprite, xpos, ypos, ItemType.WALL);
    }

}