package ghost;

import processing.core.PImage;

public class Whim extends Ghost {

    /**
     * Constructor for a whim
     * @param normal PImage for the ghost during chase and scatter
     * @param frightened PImage for the ghost when frightened
     * @param xspawn Pixel row position of the spawn location
     * @param yspawn Current column pixel position of the character, from the top left corner
     * @param speed The number of pixels it moves per frame
     * @param targetDefault Cell location of the ghost's default corner during scatter
     * @param frightenedLength Length of frighten time in frames
     * @param modeLength Time length of scatter and chase modes
     */
    public Whim(PImage normal, PImage frightened, int xspawn, int yspawn, long speed, 
    int[]targetDefault, long frightenedLength, long[] modeLength) {
        super(normal, frightened, xspawn, yspawn, speed, targetDefault, frightenedLength, 
        modeLength, GhostType.WHIM);
    }

    /**
     * If there is no chaser, return waka's position. Else return the cell coordinates that are two 
     * times the distance from waka to two spaces infront of waka
     */
    public int[] updateTarget(Waka waka, Ghost chaser)  {
        // Get distance from chaser to waka and double
        if (waka == null) {
            return null;
        }

        // If there is no chaser available, target is waka
        if (chaser == null) {
            return waka.getCell();
        } else {
            int wakax = waka.getCell()[0];
            int wakay = waka.getCell()[1];

            // Find two cells in front of waka, if waka isn't moving then just get the position of waka
            if (waka.dx > 0) {
                wakax += 2;
            } else if (waka.dx < 0) {
                wakax -= 2;
            } else if (waka.dy > 0) {
                wakay += 2;
            } else if (waka.dy < 0) {
                wakay -= 2;
            }

            int chaserx = chaser.getCell()[0];
            int chasery = chaser.getCell()[1];

            int xdistance = (wakax-chaserx) * 2;
            int ydistance = (wakay-chasery) * 2;

            // double distance = Math.hypot(chaserx-wakax, chasery-wakay) * 2;
            int targetx = chaserx + xdistance;
            int targety = chasery + ydistance;
            int[] target = new int[2];

            // Check if the target is in the board
            // Check target cell is within the board
            if (targetx < 36 && targetx >= 0 && targety < 28 && targety >= 0) {
                target[0] = targetx;
                target[1] = targety;
            } else {
                // If target isn't in board, make target the boarder
                if (targetx >= 36) {
                    targetx = 35;
                }
                if (targetx < 0) {
                    targetx = 0;
                }
                if (targety >= 28) {
                    targety = 27;
                }
                if (targety < 0) {
                    targety = 0;
                }

                target[0] = targetx;
                target[1] = targety;
            }

            

            return target;
        }
        
    }

}