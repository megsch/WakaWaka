package ghost;

import processing.core.PImage;
import processing.core.PApplet;

public class Waka extends Character {
 
    private boolean isOpen = true;

    private PImage WAKACLOSED;
    private PImage WAKADOWN;
    private PImage WAKALEFT;
    private PImage WAKARIGHT;
    private PImage WAKAUP;
    private int openCount;
    
    private PImage currentState;
    private int keyCode;

    /**
     * Constructor for waka
     * @param xspawn Pixel column position of the spawn location
     * @param yspawn Pixel row position of the spawn location
     * @param closed PImage
     * @param down PImage
     * @param left PImage
     * @param right PImage
     * @param up PImage
     * @param speed pixels per frame
     */
    public Waka(int xspawn, int yspawn, PImage closed, PImage down, PImage left, PImage right,
    PImage up, long speed) {
        super(xspawn, yspawn, speed);
        WAKACLOSED = closed;
        WAKADOWN = down;
        WAKALEFT = left;
        WAKARIGHT = right;
        WAKAUP = up;
        currentState = WAKALEFT;
        openCount = 1;
        dy -= speed;    // Go left from start
        // dx -= speed;
    }

    /**
     * Handles the movement and updates the current state. If waka is able to change direction
     * based off the keyCode or continue straight move waka, else stop. Changes waka's mouth.
     * @param boardObjects Item array of board objects
     */
    public void tick(Item[][] boardObjects) {
        // Movement & update currentState
        
        // Check if key direction is clear or can go straight
        if (changeDirection(boardObjects) == true || checkStraight(boardObjects) == true) {
            this.move(boardObjects);
        } else {
            // If key direction and straight ahead are not clear, stop
            clearSpeed();
        }

        // Update open and closed mouth
        if (openCount == 8) {
            openCount = 0;
            if (isOpen) {
                isOpen = false;
            } else {
                isOpen = true;
            }
        }
        openCount += 1;
    }

    /**
     * @return If waka's mouth is open
     */
    public boolean getIsOpen() {
        return isOpen;
    }

    /**
     * Draw waka.
     */
    public void draw(PApplet app) {
        app.image(this.currentImage(), ypos, xpos);
    }

    /**
     * Based of direction change the current state to the correct PImage
     */
    public void updateCurrentState() {
        if (dx < 0) {
            currentState = WAKAUP;
        } else if (dx > 0) {
            currentState = WAKADOWN;
        } else if (dy < 0) {
            currentState = WAKALEFT;
        } else if (dy > 0) {
            currentState = WAKARIGHT;
        }
    }
    
    /**
     * Return PImage of waka's closed mouth, or facing different directoins.
     * @return PImage of current state
     */
    public PImage currentImage() {
        // Return correct image to display
        this.updateCurrentState();

        if (!isOpen) {
            return WAKACLOSED;
        } else {
            return currentState;
        }
    }

    /**
     * Changes keyCode when key is pressed
     * @param key keycode that refers to a key
     */
    public void changeKey(int key) {
        this.keyCode = key;
    }

    /**
     * @return int of the key pressed
     */
    public int getKey() {
        return keyCode;
    }


    /**
     * Check if the waka can follow key instructions and change velocity
     * Check that the waka's center position is in the center of a cell
     * @param boardObjects Item array of board objects
     * @return If waka can change direction
     */
    public boolean changeDirection(Item[][] boardObjects) {
        
        int correctX = this.getCell()[0] * 16 + 3;
        int correctY = this.getCell()[1] * 16 + 3;

        if (Math.abs(this.getCenterPoint()[0] - correctX) < 6 && 
        Math.abs(this.getCenterPoint()[1] - correctY) < 6) {
            boolean hasChanged = false;
            

            if (keyCode == 39) {
                // System.out.println("Right");
                if (!(dy > 0) && checkRight(boardObjects)) {
                    right();
                    hasChanged = true;;
                }
            } else if (keyCode == 37) {
                // System.out.println("Left");
                if (!(dy < 0) && checkLeft(boardObjects)) {
                    left();
                    hasChanged = true;
                }
            } else if (keyCode == 38) {
                // System.out.println("Up");
                if (!(dx < 0) && checkUp(boardObjects)) {
                    up();
                    hasChanged = true;
                }
            } else if (keyCode == 40) {
                // System.out.println("Down");
                if (!(dx > 0) && checkDown(boardObjects)) {
                    down();
                    hasChanged = true;
                }
            } 

            if (hasChanged) {
                // If waka is close to the cell's center, change waka's center to cell's center
                this.xpos = correctX - 8;
                this.ypos = correctY - 8;
                this.updateCenterPoint();
                return true;
            }
        }

        return false;

    }

    public void backToStart() {
        this.xpos = this.xspawn;
        this.ypos = this.yspawn;
        updateCell();
        updateCenterPoint();
        clearSpeed();
        this.dy -= speed;
    }

    

}