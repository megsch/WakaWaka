package ghost;

import processing.core.PImage;
import processing.core.PApplet;

// For Inanimate objects
public abstract class Item {

    /**
     * Different Item types
     */
    enum ItemType {
        FRUIT,
        SUPERFRUIT,
        WALL,
        LIFE
    }

    protected PImage sprite;
    protected int xpos;
    protected int ypos;
    protected int[] cell;
    protected int[] centerPoint;
    protected ItemType type;

    /**
     * Constructor for an item
     * @param sprite PImage
     * @param xpos pixel position in a column
     * @param ypos pixel position in a row
     * @param type ItemType
     */
    public Item(PImage sprite, int xpos, int ypos, ItemType type) {
        this.sprite = sprite;
        this.xpos = xpos * 16 ;//+ 5;
        this.ypos = ypos * 16; //- 5;
        this.type = type;
        cell = new int[] {xpos, ypos};
        centerPoint = new int[] {this.xpos + 8, this.ypos + 8};
    }

    /**
     * @return x postion
     */
    public int getX() {
        return this.xpos;
    }

    /**
     * @return y position
     */
    public int getY() {
        return this.ypos;
    }

    /**
     * @return cell position
     */
    public int[] getcell() {
        return cell;
    }

    /**
     * @return center point
     */
    public int[] getCenterPoint() {
        return centerPoint;
    }

    /**
     * Draw the Item
     * @param app App object
     */
    public void draw(PApplet app) {
        app.image(sprite, ypos, xpos);
    }

    /**
     * @return enum ItemType
     */
    public ItemType getType() {
        return type;
    }

}