package ghost;

import processing.core.PImage;

public class Ignorant extends Ghost {

    /**
     * Constructor for an ignorant
     * @param normal PImage for the ghost during chase and scatter
     * @param frightened PImage for the ghost when frightened
     * @param xspawn Pixel row position of the spawn location
     * @param yspawn Current column pixel position of the character, from the top left corner
     * @param speed The number of pixels it moves per frame
     * @param targetDefault Cell location of the ghost's default corner during scatter
     * @param frightenedLength Length of frighten time in frames
     * @param modeLength Time length of scatter and chase modes
     */
    public Ignorant(PImage normal, PImage frightened, int xspawn, int yspawn, long speed, 
    int[]targetDefault, long frightenedLength, long[] modeLength) {
        super(normal, frightened, xspawn, yspawn, speed, targetDefault, frightenedLength, 
        modeLength, GhostType.IGNORANT);
    }

    /**
     * Update target to be waka's position if it is more than 8 cells away, else return it's 
     * default target
     */
    public int[] updateTarget(Waka waka, Ghost chaser)  {
        if (waka == null) {
            return null;
        }
        
        // Find distance from waka
        int wakax = waka.getCell()[0];
        int wakay = waka.getCell()[1];
        double distance = Math.hypot(wakax-this.cell[0], wakay-this.cell[1]);
        if (distance <= 8) {
            // Target is the corner
            return this.targetDefault;
        } else {
            // Go after waka
            return waka.getCell();
        }
    }

}