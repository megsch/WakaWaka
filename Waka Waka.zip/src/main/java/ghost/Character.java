package ghost;

import ghost.Item.ItemType;

public abstract class Character {
    
    /**
     * Pixel column position of the spawn location
     */
    protected int xspawn;

    /**
     * Pixel row position of the spawn location
     */
    protected int yspawn;

    /**
     * Current column pixel position of the character, from the top left corner
     */
    protected int xpos;

    /**
     * Current row pixel position of the character, from the top left corner
     */
    protected int ypos;

    /**
     * The speed in the vertical directions
     */
    protected int dx;

    /**
     * The speed in the horizontal direction
     */
    protected int dy;

    /**
     * The number of pixels it moves per frame
     */
    protected long speed;

    /**
     * The cell position of the character, int[x,y]
     */
    protected int[] cell;

    /**
     * The centerpoint of the character in pixels, int[x,y]
     */
    protected int[] centerPoint;

    /**
     * Constructor for a character. Default speed is 0.
     * @param xpos the column location of the character
     * @param ypos the row location of the character
     * @param speed the number of pixels it moves per frame
     */
    public Character(int xpos, int ypos, long speed) {
        this.xpos = xpos * 16 - 5;
        this.ypos = ypos * 16 -5;
        this.xspawn = xpos * 16 - 5;
        this.yspawn = ypos * 16 - 5;
        this.dx = 0;
        this.dy = 0;
        this.speed = speed;
        this.cell = new int[] {xpos, ypos};
        this.centerPoint = new int[] {this.xpos + 8, this.ypos + 8};
    }

    /**
     * @return speed in vertical direction
     */
    public int getdx() {
        return dx;
    }

    /**
     * @return speed in horizontal direction
     */
    public int getdy() {
        return dy;
    }

    /**
     * Change dx to be negative
     */
    public void up() {
        // Change direction
        this.clearSpeed();
        this.dx -= speed;
    }

    /**
     * Change dx to be positive
     */
    public void down() {
        // Change direction
        this.clearSpeed();
        this.dx += speed;
    }

    /**
     * Change dy to be negative
     */
    public void left() {
        // Change direction
        this.clearSpeed();
        this.dy -= speed;
    }

    /**
     * Change dy to be positive
     */
    public void right() {
        // Change direction
        this.clearSpeed();
        this.dy += speed;
    }

    /**
     * Clear character's speed, make dy and dx zero
     */
    public void clearSpeed() {
        this.dx = 0;
        this.dy = 0;
    }

    /**
     * Change the character's xpos and ypos based off it's current dx and dy. Call updateCell() and
     * updateCenterPoint()
     * @param boardObjects Item array of board objects
     */
    public void move(Item[][] boardObjects) {
        // Move sprite position
        if (dx != 0) {
            this.xpos = xpos + dx;
        } else if (dy != 0) {
            this.ypos = ypos + dy;
        }

        this.updateCell();
        this.updateCenterPoint();
    }

    /**
     * Checks if the character can continue straight
     * @param boardObjects Item array of board objects
     * @return If the character can continue straight
     */
    public boolean checkStraight(Item[][] boardObjects) {
        // Check if sprite can continue
        if (dx != 0) {
            // Check up/down
            if (dx > 0 && checkDown(boardObjects) == false) {
                return false;
            } else if (dx < 0 && checkUp(boardObjects) == false) {
                return false;
            }
        } else if (dy != 0) {
            // Check left/right
            if (dy < 0 && checkLeft(boardObjects) == false) {
                return false;
            } else if (dy > 0 && checkRight(boardObjects) == false) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return character's current cell location
     */
    public int[] getCell() {
        return cell;
    }

    /**
     * @return character's current centerpoint location in pixels
     */
    public int[] getCenterPoint() {
        return centerPoint;
    }

    /**
     * Updates the character's current centerpoint based off the xpos and ypos
     */
    public void updateCenterPoint() {
        this.centerPoint[0] = this.xpos + 8;
        this.centerPoint[1] = this.ypos + 8;
    }

    /**
     * Update the character's current cell position based off the xpos and ypos
     */
    public void updateCell() {
        int xtmp = (xpos+8)/16;
        int ytmp = (ypos + 8)/16;
        this.cell[0] = xtmp;
        this.cell[1] = ytmp;
    }

    /**
     * Returns the character back to their starting position
     */
    public abstract void backToStart();

    /**
     * Check the space above the character.
     * @param boardObjects Item array of board objects
     * @return If the character can move up
     */
    public boolean checkUp(Item[][] boardObjects) {
        // Check if space above character is free
        boolean isFree;
        Item tmp;
        if (this.cell[0] == 0) {
            return false;
        } else {
            tmp = boardObjects[this.cell[0]-1][this.cell[1]];
        }
        

        // Check if sprite is close enough
        if (Math.abs(this.getCenterPoint()[1] - this.getCell()[1]*16) < 6) {
            if (tmp != null && Math.abs(this.getCenterPoint()[0] - tmp.getCenterPoint()[0]) < 13) {
                // If it is close enough, check if the cell is free
                // Empty space or fruit/superfruit is free
                if ( tmp == null || tmp.getType() == ItemType.FRUIT || 
                tmp.getType() == ItemType.SUPERFRUIT) {
                    isFree = true;
                } else {
                    isFree = false;
                }
            } else {
                // Sprite can still go closer
                isFree = true;
            }
        } else {
            isFree = false;
        }
        
        return isFree;
    }

    /**
     * Check the space below the character.
     * @param boardObjects Item array of board objects
     * @return If the character can move down
     */
    public boolean checkDown(Item[][] boardObjects) {
        // Check if space below character is free
        boolean isFree;
        Item tmp;
        if (this.cell[0] == 35) {
            return false;
        } else {
            tmp = boardObjects[this.cell[0]+1][this.cell[1]];
        }

        // Check if sprite is close enough
        if (Math.abs(this.getCenterPoint()[1] - this.getCell()[1]*16) < 6) {
            if (tmp != null && Math.abs(this.getCenterPoint()[0] - tmp.getCenterPoint()[0]) < 23) {
                // If it is close enough, check if the cell is free
                // Empty space or fruit/superfruit is free
                if ( tmp == null || tmp.getType() == ItemType.FRUIT || 
                tmp.getType() == ItemType.SUPERFRUIT) {
                    isFree = true;
                } else {
                    isFree = false;
                }
            } else {
                // Sprite can still go closer
                isFree = true;
            }
        } else {
            isFree =false;
        }
        
        return isFree;
    }


    /**
     * Check the space to the right of the character.
     * @param boardObjects Item array of board objects
     * @return If the character can move to the right.
     */
    public boolean checkRight(Item[][] boardObjects) {
        // Check if space on the right of the character is free
        boolean isFree;
        Item tmp;
        if (this.cell[1] == 27) {
            return false;
        } else {
            tmp = boardObjects[this.cell[0]][this.cell[1]+1];
        }

        // Check if sprite is close enough
        if (Math.abs(this.getCenterPoint()[0] - this.getCell()[0]*16) < 6) {
            if (tmp != null && Math.abs(this.getCenterPoint()[1] - tmp.getCenterPoint()[1]) < 25) {
            // If it is close enough, check if the cell is free
            // Empty space or fruit/superfruit is free
            if ( tmp == null || tmp.getType() == ItemType.FRUIT || 
            tmp.getType() == ItemType.SUPERFRUIT) {
                isFree = true;
            } else {
                isFree = false;
                }   
            } else {
            // Sprite can still go closer
            isFree = true;
            }
        } else {
            isFree = false;
        }
        
        
        return isFree;
    }

    /**
     * Check the space to the left of the character.
     * @param boardObjects Item array of board objects
     * @return If the character can move to the left.
     */
    public boolean checkLeft(Item[][] boardObjects) {
        // Check if space on the left of the character is free
        boolean isFree;
        Item tmp;
        if (this.cell[1] == 0) {
            return false;
        } else {
            tmp = boardObjects[this.cell[0]][this.cell[1]-1];
        }
        // Check if sprite is close enough
        if (Math.abs(this.getCenterPoint()[0] - this.getCell()[0]*16) < 6) {
            if (tmp != null && Math.abs(this.getCenterPoint()[1] - tmp.getCenterPoint()[1]) < 14){
            // If it is close enough, check if the cell is free
            // Empty space or fruit/superfruit is free
            if ( tmp == null || tmp.getType() == ItemType.FRUIT || 
            tmp.getType() == ItemType.SUPERFRUIT) {
                isFree = true;
            } else {
                isFree = false;
            }
            } else {
            // Sprite can still go closer
            isFree = true;
            }
        } else {
            isFree = false;
        }
        
        
        return isFree;
    }


}