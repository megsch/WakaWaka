package ghost;

import processing.core.PImage;

public class Ambusher extends Ghost {

    /**
     * Constructor for ambusher
     * @param normal PImage for the ghost during chase and scatter
     * @param frightened PImage for the ghost when frightened
     * @param xspawn Pixel row position of the spawn location
     * @param yspawn Current column pixel position of the character, from the top left corner
     * @param speed The number of pixels it moves per frame
     * @param targetDefault Cell location of the ghost's default corner during scatter
     * @param frightenedLength Length of frighten time in frames
     * @param modeLength Time length of scatter and chase modes
     */
    public Ambusher(PImage normal, PImage frightened, int xspawn, int yspawn, long speed, 
    int[]targetDefault, long frightenedLength, long[] modeLength) {
        super(normal, frightened, xspawn, yspawn, speed, targetDefault, frightenedLength, 
        modeLength, GhostType.AMBUSHER);
    }

    /**
     * Updates target to be 4 cell spaces infront of waka's position based off it's current
     * direction
     */
    public int[] updateTarget(Waka waka, Ghost chaser)  {
        int[] target = new int[2];
        int targetx = waka.getCell()[0];
        int targety = waka.getCell()[1];

        // Get cell 4 cells ahead
        if (waka.getdx() > 0) {
            // 4 cells below
            targetx = waka.getCell()[0] + 5;
            targety = waka.getCell()[1];
        } else if (waka.getdx() < 0) {
            // 4 cells above
            targetx = waka.getCell()[0] - 4;
            targety = waka.getCell()[1];
        } else if (waka.getdy() > 0) {
            // 4 cells right
            targetx = waka.getCell()[0];
            targety = waka.getCell()[1] + 5;
        } else if (waka.getdy() < 0) {
            // 4 cells left
            targetx = waka.getCell()[0];
            targety = waka.getCell()[1] - 4;
        }

        // Check target cell is within the board
        if (targetx < 36 && targetx >= 0 && targety < 28 && targety >= 0) {
            target[0] = targetx;
            target[1] = targety;
            return target;
        } else {
            // If target isn't in board, make target the boarder
            if (targetx >= 36) {
                targetx = 35;
            }
            if (targetx < 0) {
                targetx = 0;
            }
            if (targety >= 28) {
                targety = 27;
            }
            if (targety < 0) {
                targety = 0;
            }
        }

        target[0] = targetx;
        target[1] = targety;
        return target;
    }
}