package ghost;

import processing.core.PImage;

public class Life extends Item {

    /**
     * Construtor for a life sprite
     * @param sprite PImage
     * @param xpos pixel position in a column
     * @param ypos pixel position in a row
     */
    public Life(PImage sprite, int xpos, int ypos) {
        super(sprite, xpos, ypos, ItemType.LIFE);
    }
}