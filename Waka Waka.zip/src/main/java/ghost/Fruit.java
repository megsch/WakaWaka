package ghost;

import processing.core.PImage;

public class Fruit extends Item{

    /**
     * Constructor for a fruit. 
     * @param sprite PImage of the fruit
     * @param xpos the column location of the fruit
     * @param ypos the row location of the fruit
     */
    public Fruit(PImage sprite, int xpos, int ypos) {
        super(sprite, xpos, ypos, ItemType.FRUIT);
    }

}