package ghost;

import processing.core.PApplet;
import processing.core.PImage;
import java.io.*;
import processing.core.PFont;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class App extends PApplet {

    public static final int WIDTH = 448;
    public static final int HEIGHT = 576;
    private long[] modeLengths;
    private long lives;
    private String mapFile;
    private long speed;
    private long frightenedLength;

    public PImage WAKACLOSED;
    public PImage WAKADOWN;
    public PImage WAKALEFT;
    public PImage WAKARIGHT;
    public PImage WAKAUP;
    public PImage AMBUSHER;
    public PImage CHASER;
    public PImage IGNORANT;
    public PImage WHIM;
    public PImage FRIGHTENED;
    public PImage HORIZONTALWALL;
    public PImage VERTICALWALL;
    public PImage CORNERUPLEFT;
    public PImage CORNERUPRIGHT;
    public PImage CORNERDOWNLEFT;
    public PImage CORNERDOWNRIGHT;
    public PImage FRUIT;
    public PImage SUPERFRUIT;
    public PFont FONT;

    private Board board;


    /**
     * Constructor for an app
     */
    public App() {
        //Set up your objects
    }

    /**
     * Get information from config, set up framerate, images, font, and initialize and 
     * setup the board
     */
    public void setup() {
        getConfig();
        
        frameRate(60);

        // Load images
        this.WAKACLOSED = this.loadImage("playerClosed.png");
        this.WAKADOWN = this.loadImage("playerDown.png");
        this.WAKALEFT = this.loadImage("playerLeft.png");
        this.WAKARIGHT = this.loadImage("playerRight.png");
        this.WAKAUP = this.loadImage("playerUp.png");
        this.AMBUSHER = this.loadImage("ambusher.png");
        this.CHASER = this.loadImage("chaser.png");
        this.IGNORANT = this.loadImage("ignorant.png");
        this.WHIM = this.loadImage("whim.png");
        this.FRIGHTENED = this.loadImage("frightened.png");
        this.HORIZONTALWALL = this.loadImage("horizontal.png");
        this.VERTICALWALL = this.loadImage("vertical.png");
        this.CORNERUPLEFT = this.loadImage("upLeft.png");
        this.CORNERUPRIGHT = this.loadImage("upRight.png");
        this.CORNERDOWNLEFT = this.loadImage("downLeft.png");
        this.CORNERDOWNRIGHT = this.loadImage("downRight.png");
        this.FRUIT = this.loadImage("fruit.png");
        this.SUPERFRUIT = this.loadImage("fruit.png");
        this.SUPERFRUIT = this.loadImage("superfruit.png");

        // Load font
        this.FONT = this.createFont("PressStart2P-Regular.ttf", 20);
        this.textFont(this.FONT);

        if (WAKAUP == null) {
            System.out.println("WAKAUP has not loaded");
        }

        // Create objects
        this.board = new Board(this.mapFile, HORIZONTALWALL, VERTICALWALL, CORNERUPLEFT, 
        CORNERUPRIGHT, CORNERDOWNLEFT, CORNERDOWNRIGHT, FRUIT, SUPERFRUIT, WAKACLOSED, WAKADOWN, 
        WAKALEFT, WAKARIGHT, WAKAUP, AMBUSHER, CHASER, IGNORANT, WHIM, FRIGHTENED, modeLengths, 
        lives, speed, frightenedLength);
        this.board.setup();
        

    }


    /**
     * Makes the app size width 448 and height 576
     */
    public void settings() {
        size(WIDTH, HEIGHT);
    }


    /**
     * Call draw() each framerate, set up a black background, call the board tick() and draw()
     */
    public void draw() { 
        background(0,0,0);

        this.board.tick(this);
        this.board.draw(this);
    }

    /**
     * Called everytime a key is pressed. If spacebar is pressed, the changeDebugMode() is called.
     * Else the changeKey() is called.
     */
    public void keyPressed() {
        if (key == CODED) {
            this.board.getWaka().changeKey(keyCode);
        } else if (key == ' ') {
            System.out.println("Space");
            this.board.changeDebugMode();
        }
        
    }


    /**
     * Read the configurations from the json file and store the configs in the app attributes
     */
    public void getConfig() {
        JSONParser jsonparser = new JSONParser();

        try {
            String filePath = new File("config.json").getAbsolutePath();
            FileReader reader = new FileReader(filePath);

            Object obj = jsonparser.parse(reader);
            

            JSONObject configs = (JSONObject) obj;
            System.out.println(configs);

            if (configs.get("map") != null) {
                mapFile = (String) configs.get("map");
            }
            if (configs.get("lives") != null) {
                lives = (long) configs.get("lives");
            }
            if (configs.get("speed") != null) {
                speed = (long) configs.get("speed");
            }
            if (configs.get("modeLengths") != null) {
                JSONArray jsonArray = (JSONArray) configs.get("modeLengths");
                long[] list = new long[jsonArray.size()];
                for (int i=0; i < jsonArray.size(); i++) {
                    long tmp = (long) jsonArray.get(i);
                    list[i] = tmp;
                }
                modeLengths = list;

            }
            if (configs.get("frightenedLength") != null) {
                frightenedLength = (long) configs.get("frightenedLength");
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        PApplet.main("ghost.App");
    }

}