package ghost;

import java.util.*;

import ghost.Ghost.GhostType;
import ghost.Item.ItemType;

import java.io.*;
import java.lang.Character;

import processing.core.PImage;
import processing.core.PApplet;

public class Board {

    public Character[][] board;
    public ArrayList<Wall> walls;
    public ArrayList<Fruit> fruits;
    public ArrayList<Superfruit> superfruits;
    public Item[][] boardObjects;


    private PImage HORIZONTALWALL;
    private PImage VERTICALWALL;
    private PImage CORNERUPLEFT;
    private PImage CORNERUPRIGHT;
    private PImage CORNERDOWNLEFT;
    private PImage CORNERDOWNRIGHT;
    private PImage FRUIT;
    private PImage SUPERFRUIT;
    private PImage WAKACLOSED;
    private PImage WAKADOWN;
    private PImage WAKALEFT;
    private PImage WAKARIGHT;
    private PImage WAKAUP;
    private PImage AMBUSHER;
    private PImage CHASER;
    private PImage IGNORANT;
    private PImage WHIM;
    private PImage FRIGHTENED;

    private final Character EMPTYCELLSYMBOL = '0';
    private final Character HORIZONTALWALLSYMBOL = '1';
    private final Character VERTICALWALLSYMBOL = '2';
    private final Character CORNERUPLEFTSYMBOL = '3';
    private final Character CORNERUPRIGHTSYMBOL = '4';
    private final Character CORNERDOWNLEFTSYMBOL = '5';
    private final Character CORNERDOWNRIGHTSYMBOL = '6';
    private final Character FRUITSYMBOL = '7';
    private final Character SUPERFRUITSYMBOL = '8';
    private final Character WAKASTART = 'p';
    private final Character AMBUSHERSTART = 'a';
    private final Character CHASERSTART = 'c';
    private final Character IGNORANTSTART = 'i';
    private final Character WHIMSTART = 'w';
    
    private ArrayList<Life> lifeObjects;
    private Waka waka;
    private ArrayList<Ghost> ghosts;

    private boolean isDebug;
    private long[] modeLength;
    private long lives;
    private long speed;
    private long frightenedLength;
    private double endScreenCount;
    private double debugBuffer;

    /**
     * Constructor for the board
     * @param filename filename of the board
     * @param horizontal PImage of wall
     * @param vertical PImage of wall
     * @param cornerUpLeft PImage of wall
     * @param cornerUpRight PImage of wall
     * @param cornerDownLeft PImage of wall
     * @param cornerDownRight PImage of wall
     * @param fruit PImage of fruit
     * @param superfruit PIamge of superfruit
     * @param wakaclosed PImage of waka
     * @param wakadown PImage of waka
     * @param wakaleft PImage of waka
     * @param wakaright PImage of waka
     * @param wakaup PImage of waka
     * @param ambusher PImage of ambusher
     * @param chaser PImage of chaser
     * @param ignorant PImage of ignorant
     * @param whim PImage of whim
     * @param frightened PImage of frightened
     * @param modeLength Array of modelengths
     * @param lives number of lives
     * @param speed
     * @param frightenedLength 
     */    
    public Board(String filename, PImage horizontal, PImage vertical, PImage cornerUpLeft, 
    PImage cornerUpRight, PImage cornerDownLeft, PImage cornerDownRight, PImage fruit, 
    PImage superfruit, PImage wakaclosed, PImage wakadown, PImage wakaleft, PImage wakaright,
    PImage wakaup, PImage ambusher, PImage chaser, PImage ignorant, PImage whim, 
    PImage frightened, long[] modeLength, long lives, long speed, long frightenedLength) {
        board = getBoardFromFile(filename);
        this.HORIZONTALWALL = horizontal;
        this.VERTICALWALL = vertical;
        this.CORNERUPLEFT = cornerUpLeft;
        this.CORNERUPRIGHT = cornerUpRight;
        this.CORNERDOWNLEFT = cornerDownLeft;
        this.CORNERDOWNRIGHT = cornerDownRight;
        this.FRUIT = fruit;
        this.SUPERFRUIT = superfruit;
        this.WAKACLOSED = wakaclosed;
        this.WAKADOWN = wakadown;
        this.WAKALEFT = wakaleft;
        this.WAKARIGHT = wakaright;
        this.WAKAUP = wakaup;
        this.AMBUSHER = ambusher;
        this.CHASER = chaser;
        this.IGNORANT = ignorant;
        this.WHIM = whim;
        this.FRIGHTENED = frightened;
        this.walls = new ArrayList<>();
        this.fruits = new ArrayList<>();
        this.superfruits = new ArrayList<>();
        this.boardObjects = new Item[36][28];
        this.ghosts = new ArrayList<>();
        this.lifeObjects = new ArrayList<>();
        this.isDebug = false;
        this.modeLength = modeLength;
        this.lives = lives;
        this.speed = speed;
        this.frightenedLength = frightenedLength;
        
    }

    /**
     * Reads the game board from the given file and turns it into a 2D character array.
     * @param filename of the game board
     * @return Character array of the board
     */
    public Character[][] getBoardFromFile(String filename) {
        // Get board from file
        
        Character[][] board = new Character[36][28];


        try {
            File f = new File(filename);
            Scanner scan = new Scanner(f);

            // Loop through lines in file
            int row = 0;
            while (scan.hasNextLine()) {
                String line = scan.nextLine();

                // Loop through each character in line
                for (int col = 0; col < line.length(); col++) {
                    // Add them to array
                    board[row][col] = Character.valueOf(line.charAt(col));
                }

                row++;
            }

            scan.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }

        return board;
    }


    /**
     * Calls the createItems() and getLives(). Call when setting up the game board.
     */
    public void setup() {
        this.createItems();
        this.getLives();
    }
    
    /**
     * @return 2D character array of the board.
     */
    public Character[][] getBoard() {
        return board;
    }

    /**
     * @return 2D Item array of the board
     */
    public Item[][] getItems() {
        return boardObjects;
    }

    /**
     * @return returns the waka object
     */
    public Waka getWaka() {
        return this.waka;
    }

    /**
     * @return returns ghosts
     */
    public ArrayList<Ghost> getGhosts() {
        return ghosts;
    }

    /**
     * @return returns fruits
     */
    public ArrayList<Fruit> getFruits() {
        return fruits;
    }

    /**
     * @return return superfruits
     */
    public ArrayList<Superfruit> getSuperfruits() {
        return superfruits;
    }

    /**
     * @return returns walls
     */
    public ArrayList<Wall> getWalls() {
        return walls;
    }

    /**
     * @return returns lifes
     */
    public ArrayList<Life> getLifes() {
        return lifeObjects;
    }

    /**
     * Makes Item, ghost, and waka instances from the 2D character array, and store these instances
     * in a 2D Item array and their respective fruit, superfruit and ghost arraylists.
     */
    public void createItems() {
        // Make objects in board, and add them to the Array lists
        for (int rowInd = 0; rowInd < this.getBoard().length; rowInd++) {
            Character[] row = this.getBoard()[rowInd];
            
            for (int colInd = 0; colInd < row.length; colInd++) {
                PImage tmpImg = this.equivalentPImage(row[colInd]);

                // Make objects
                if (row[colInd] == FRUITSYMBOL) {
                    Fruit tmp = new Fruit(tmpImg, rowInd, colInd);
                    this.fruits.add(tmp);
                    this.boardObjects[rowInd][colInd] = tmp;
                } else if (row[colInd] == SUPERFRUITSYMBOL){
                    Superfruit tmp = new Superfruit(tmpImg, rowInd, colInd);
                    this.superfruits.add(tmp);
                    this.boardObjects[rowInd][colInd] = tmp;
                } else if (row[colInd] == WAKASTART) {
                    this.waka = new Waka(rowInd, colInd, WAKACLOSED, WAKADOWN, WAKALEFT, 
                    WAKARIGHT, WAKAUP, speed);
                } else if (row[colInd] == AMBUSHERSTART) {
                    Ambusher tmp = new Ambusher(tmpImg, FRIGHTENED, rowInd, colInd, speed, 
                    new int[] {0, 28}, frightenedLength, modeLength);
                    this.ghosts.add(tmp);
                } else if (row[colInd] == CHASERSTART) {
                    Chaser tmp = new Chaser(tmpImg, FRIGHTENED, rowInd, colInd, speed, 
                    new int[] {0, 0}, frightenedLength, modeLength);
                    this.ghosts.add(tmp);
                } else if (row[colInd] == IGNORANTSTART) {
                    Ignorant tmp = new Ignorant(tmpImg, FRIGHTENED, rowInd, colInd, speed, 
                    new int[] {36, 0}, frightenedLength, modeLength);
                    this.ghosts.add(tmp);
                } else if (row[colInd] == WHIMSTART) {
                    Whim tmp = new Whim(tmpImg, FRIGHTENED, rowInd, colInd, speed, 
                    new int[] {36, 28}, frightenedLength, modeLength);
                    this.ghosts.add(tmp);
                } else if (row[colInd] != EMPTYCELLSYMBOL) {
                    // Make wall object
                    Wall tmp = new Wall(tmpImg, rowInd, colInd);
                    this.walls.add(tmp);
                    this.boardObjects[rowInd][colInd] = tmp;
                }           
            }

        }

        // Set up targets for ghost
        for (Ghost g : ghosts) {
            g.updateTarget(waka, null);
        }

    }

    /**
     * Returns the equivalent PImage based off the Character given
     * @param symbol that represents an Item of the board.
     * @return PImage of the Item.
     */
    public PImage equivalentPImage(Character symbol) {
        if (symbol == this.EMPTYCELLSYMBOL) {
            return null;
        } else if (symbol == this.HORIZONTALWALLSYMBOL) {
            return this.HORIZONTALWALL;
        } else if (symbol == this.VERTICALWALLSYMBOL) {
            return this.VERTICALWALL;
        } else if (symbol == this.CORNERUPLEFTSYMBOL) {
            return this.CORNERUPLEFT;
        } else if (symbol == this.CORNERUPRIGHTSYMBOL) {
            return this.CORNERUPRIGHT;
        } else if (symbol == this.CORNERDOWNLEFTSYMBOL) {
            return this.CORNERDOWNLEFT;
        } else if (symbol == this.CORNERDOWNRIGHTSYMBOL) {
            return this.CORNERDOWNRIGHT;
        } else if (symbol == this.FRUITSYMBOL) {
            return this.FRUIT;
        } else if (symbol == this.SUPERFRUITSYMBOL) {
            return this.SUPERFRUIT;
        } else if (symbol == this.AMBUSHERSTART) {
            return this.AMBUSHER;
        } else if (symbol == this.CHASERSTART) {
            return this.CHASER;
        } else if (symbol == this.IGNORANTSTART) {
            return this.IGNORANT;
        } else if (symbol == this.WHIMSTART) {
            return this.WHIM;
        }

        return null;
    }

    /**
     * From the amount of lives the waka in the config file, create the amount of lives as
     * Life instances and add them to the lifeObjects arraylist.
     */
    public void getLives() {
        // Make life sprites and add to arraylist
        int livesInt = (int) lives;
        int xpos = 34;
        int ypos = 1;
        for (int i = 1; i <= livesInt; i++) {
            Life tmp = new Life(WAKARIGHT, xpos, ypos);
            this.lifeObjects.add(tmp);
            ypos += 2;
        }
    }

    /**
     * Goes through the Item[][], the ghosts and waka and calls every object's draw function.
     * If the player has won or lost, draw the win or lose screen for 10 seconds.
     * @param app Papplet app object
     */
    public void draw(PApplet app) {
        // Check if won/lost. Draw lost/win screen. Else draw board
        Boolean won = checkWin();
        if (won == null) {
            // Draw board
            for (Fruit f : this.fruits) {
                f.draw(app);
            }
    
            for (Superfruit s : this.superfruits) {
                s.draw(app);
            }

            for (Wall w : this.walls) {
                w.draw(app);
            }
            
            this.waka.draw(app);

            for (Ghost g : this.ghosts) {
                // Draw if ghost is not removed
                if (g.isRemoved() == false) {
                    g.draw(app);
                }
            }
            
            for (Life l : this.lifeObjects) {
                l.draw(app);
            }

            // If debug mode is on, draw lines
            if (isDebug) {
                for (Ghost g : this.ghosts) {
                    if (g.isRemoved() == false) {
                        drawLines(app, g);
                    }
                }
            }

        } else if (won == true) {
            drawWinScreen(app);
        } else if (won == false) {
            drawLoseScreen(app);
        } 
        

    }

    /**
     * Handles the logics of the game. Calls the waka and ghosts tick(). Handles the debug counter.
     * Resets board if the end screens have finished.
     * @param app Papplet app object
     */
    public void tick(PApplet app) {
        // If waka has won or lost, pause game
        Boolean won = checkWin();

        if (won == null) {
            this.waka.tick(boardObjects);
            removeFruits();

            

            // Find available chaser
            Ghost availableChaser = null;
            for (Ghost g: this.ghosts) {
                // Find chaser that is not caught by waka
                if (g.getType() == GhostType.CHASER && g.isRemoved == false) {
                    availableChaser = g;
                    break;
                } 
            }

            for (Ghost g : this.ghosts) {
                // If ghost is not removed, tick
                if (g.isRemoved() == false) {
                    g.tick(boardObjects, waka, availableChaser);
                }
            }

            // Check waka and ghost collision
            for (Ghost g : this.ghosts) {
                if (checkCollision(g) == true) {
                    // If ghost is frightened, remove ghost
                    if (g.isFrightened) {
                        g.remove();
                    } else {
                        // Waka loses a life
                        this.lifeObjects.remove(this.lifeObjects.size()-1);
                        backToStart();
                        break;
                    }
                    
                } 
            }

            // If spacebar is hit, toggle debug, work debug buffer
            if (debugBuffer > 0) {
                debugBuffer--;
            }



        } else {
            if (screenCount() == true) {
                resetBoard();
            }
        } 

    }

    /**
     * Removes any fruit in the same cell as waka. If superfruit is removed, call fright()
     */
    public void removeFruits() {
        // Remove any fruits/superfruit in the same cell as waka
        int[] wakaCell = waka.getCell();
        Item tmp = boardObjects[wakaCell[0]][wakaCell[1]];
        if (tmp != null) {
            if (tmp.getType() == ItemType.FRUIT) {
                this.fruits.remove(tmp);
                boardObjects[wakaCell[0]][wakaCell[1]] = null;
            } else if (tmp.getType() == ItemType.SUPERFRUIT) {
                this.superfruits.remove(tmp);
                boardObjects[wakaCell[0]][wakaCell[1]] = null;
                // Start Frightened timer
                for (Ghost g : this.ghosts) {
                    g.fright();
                }
            }
        }
    }

    /**
     * Checks if the player has won or lost.
     * @return Returns true if fruits and superfruits arraylist is empty. Returns false if lifeObjects
     * arraylist is empty. Else return null.
     */
    public Boolean checkWin() {
        // Returns true if won, false if lose, else null
        if (this.fruits.size() == 0 && this.superfruits.size() == 0) {
            return true;
        } else if (this.lifeObjects.size() == 0) {
            return false;
        } else {
            return null;
        }
    }

    /**
     * Toggles the isDebug attribute, and calls the resetDebugBuffer()
     */
    public void changeDebugMode() {
        // Changes Debug mode
        if (isDebug == true && debugBuffer <= 0) {
            isDebug = false;
            resetDebugBuffer();
        } else if (debugBuffer <= 0) {
            isDebug = true;
            resetDebugBuffer();
            
        }
    }

    /**
     * Sets debug buffer to 20.
     */
    public void resetDebugBuffer() {
        this.debugBuffer = 20;
    }

    /**
     * @return If the game is in debug mode
     */
    public boolean getDebugState() {
        return isDebug;
    }

    /**
     * Decrease debug buffer by one.
     */
    public void minusDebugBuffer() {
        debugBuffer -= 1;
    }

    /**
     * Draw the text of the win screen
     * @param app Papplet app object
     */
    public void drawWinScreen(PApplet app) {
        app.text("YOU WIN", 145, 230);
    }

    /**
     * Draw the text of the lose screen
     * @param app Papplet app object
     */
    public void drawLoseScreen(PApplet app) {
        app.text("GAME OVER", 130, 230);
    }

    /**
     * Counts to 10 seconds when the end screens are drawn
     * @return Returns true if count reaches 10 seconds, else false
     */
    public boolean screenCount() {
        this.endScreenCount++;
        if (this.endScreenCount >= 600) {
            this.endScreenCount = 0;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @return end screen count
     */
    public double getScreenCount() {
        return endScreenCount;
    }

    /**
     * Resets the board. Clears the arraylists of Items, and recreates the board
     */
    public void resetBoard() {
        // Clear arraylist of life sprites and ghosts
        this.lifeObjects.clear();
        this.ghosts.clear();
        this.fruits.clear();
        this.superfruits.clear();
        
        // Reset board items array
        createItems();
        getLives();

        isDebug = false;
        resetDebugBuffer();
     
    }

    /**
     * Checks if waka and ghost collide.
     * @param g Ghost
     * @return true if they collide, false if they don't.
     */
    public boolean checkCollision(Ghost g) {
        // Check if ghost has collided with waka
        int gxposOther = g.xpos + 28;
        int gyposOther = g.ypos + 28;
        int wxposOther = waka.xpos + 25;
        int wyposOther = waka.ypos + 25;


        if (waka.xpos < gxposOther && wxposOther > g.xpos && waka.ypos < gyposOther &&
        wyposOther > g.ypos) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * If waka and ghost collide, and waka loses a life, then backToStart() is called.
     * Returns waka and ghosts to their starting positions.
     */
    public void backToStart() {
        // Set waka and ghost to starting positions
        waka.backToStart();
        for (Ghost g : this.ghosts) {
            g.backToStart();
        }
    }

    /**
     * If debug mode is on, drawlines draws lines from the ghost to their target
     * @param app PApplet
     * @param g Ghost
     */
    public void drawLines(PApplet app, Ghost g) {
        int[] currentTarget = g.getCurrentTarget();
        app.stroke(200);
        app.line(g.getCenterPoint()[1], g.getCenterPoint()[0], currentTarget[1] * 16, currentTarget[0] * 16);
    }

}