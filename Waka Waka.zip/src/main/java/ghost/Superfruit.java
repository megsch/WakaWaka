package ghost;

import processing.core.PImage;

public class Superfruit extends Item {

    /**
     * Constructor for a superfruit
     * @param sprite PImage
     * @param xpos pixel position in a column
     * @param ypos pixel position in a row
     */
    public Superfruit(PImage sprite, int xpos, int ypos) {
        super(sprite, xpos, ypos, ItemType.SUPERFRUIT);
        this.xpos = this.xpos - 7;
        this.ypos = this.ypos - 7;

    }

}