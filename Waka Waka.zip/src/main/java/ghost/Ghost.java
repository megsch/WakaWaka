package ghost;

import processing.core.PApplet;
import processing.core.PImage;

import java.util.*;
import static java.lang.Math.hypot;

public abstract class Ghost extends Character {
    
    enum GhostType {
        AMBUSHER,
        CHASER,
        IGNORANT,
        WHIM
    }
    
    protected PImage NORMAL;
    protected PImage FRIGHTENED;
    protected int[] currentTarget;
    protected int[] targetDefault;
    protected long frightenedLength;
    protected long frightenedCountdown;
    protected boolean isFrightened;
    protected boolean isRemoved;
    protected long[] modeLength;
    protected long[] modeCount;
    protected boolean isScatter;
    protected GhostType type;
    protected ArrayList<Directions> oldestBacktrack;

    /**
     * Constructor for a ghost.
     * @param normal PImage for the ghost during chase and scatter
     * @param frightened PImage for the ghost when frightened
     * @param xspawn Pixel row position of the spawn location
     * @param yspawn Current column pixel position of the character, from the top left corner
     * @param speed The number of pixels it moves per frame
     * @param targetDefault Cell location of the ghost's default corner during scatter
     * @param frightenedLength Length of frighten time in frames
     * @param modeLength Time length of scatter and chase modes
     * @param type Type of ghost
     */
    public Ghost(PImage normal, PImage frightened, int xspawn, int yspawn, long speed, 
    int[]targetDefault, long frightenedLength, long[] modeLength, GhostType type) {
        super(xspawn, yspawn, speed);
        this.NORMAL = normal;
        this.FRIGHTENED = frightened;
        this.targetDefault = targetDefault;
        this.frightenedLength = frightenedLength * 60;
        this.frightenedCountdown = frightenedLength;
        isFrightened = false;
        isRemoved = false;
        this.modeLength = modeLength;
        this.modeCount = setupModeCount();
        isScatter = false;
        this.type = type;
        this.oldestBacktrack = new ArrayList<>();
    }

    /**
     * @return Ghost type
     */
    public GhostType getType() {
        return type;
    }

    /**
     * Draw the ghost
     * @param app App object
     */
    public void draw(PApplet app) {
        app.image(currentImage(), ypos, xpos);
    }

    /**
     * @return frightened PImage if ghost is frightened, otherwise normal PImage
     */
    public PImage currentImage() {
        if (isFrightened) {
            return FRIGHTENED;
        } else {
            return NORMAL;
        }
    }

    /**
     * Set up the modecount, changing the time seconds to frames
     * @return modecount in frames
     */
    public long[] setupModeCount() {
        // Set up modeCount in number of frames
        
        long[] tmp = new long[this.modeLength.length];
        for (int i = 0; i < modeLength.length; i++) {
            tmp[i] = this.modeLength[i] * 60;
        }
        return tmp;
    }

    /**
     * Keeps track of the ghost's scatter and chase modes
     */
    public void countMode() {
        int index = 0;

        while (index < modeLength.length) {
            if (modeCount[index] == 0) {
                index++;
            } else {
                break;
            }
        }
        // If array has been traversed, restart array
        if (index >= modeLength.length) {
            this.modeCount = setupModeCount();
            index = 0;
        }

        // Get mode, odd is chase, even is scatter
        if (index % 2 == 0) {
            isScatter = true;
        } else {
            isScatter = false;
        }

        // Countdown
        modeCount[index] -= 1;
    }

    public boolean isScatter() {
        return isScatter;
    }

    /**
     * Change ghost to frighten mode, and start frightened countdown
     */
    public void fright() {
        this.isFrightened = true;
        this.isScatter = false;
        // Set frightened countdown
        this.frightenedCountdown = this.frightenedLength;
    }

    /**
     * Reduce the frightened count every frame. Change isFrightened to false once count is over.
     * @return true if ghost is still frightened.
     */
    public boolean checkFrightened() {
        // Updates frightened countdown and checks if ghost is still frightened
        this.frightenedCountdown -= 1;

        if (frightenedCountdown <= 0) {
            isFrightened = false;

        }

        return isFrightened;
    }

    /**
     * @return frightened state
     */
    public boolean getFrightened() {
        return isFrightened;
    }

    /**
     * @return is removed
     */
    public boolean isRemoved() {
        return isRemoved;
    }

    /**
     * Remove ghost
     */
    public void remove() {
        isRemoved = true;
    }

    /**
     * Replace ghost if it is removed
     */
    public void replace() {
        // If removed, replace
        isRemoved = false;
    }

    /**
     * Returns ghost to it's starting position. If it is removed, replace it.
     */
    public void backToStart() {
        this.xpos = this.xspawn;
        this.ypos = this.yspawn;
        updateCell();
        updateCenterPoint();
        clearSpeed();
        this.isFrightened = false;
        this.replace();
    }

    /**
     * Finds the possible moves. If it is in chase or scatter mode, finds the direction closest to it's 
     * target. If it is in frightened mode, select a random direction from the possible moves. Then moves
     * in that direction.
     * @param boardObjects Item array of board objects
     * @param waka Waka
     * @param chaser Chaser
     */
    public void tick(Item[][] boardObjects, Waka waka, Ghost chaser) {
        // Check for possible intersections
        ArrayList<Directions> possibleMoves = findPossibleMoves(boardObjects);
        
        if (backtrackVelocityDirection() != null) {
            oldestBacktrack.add(backtrackVelocityDirection());
        }
        
        Directions newBacktrack = null;

        // Keep latest of six
        if (oldestBacktrack.size() > 6) {
            oldestBacktrack.remove(0);
        }
        
        // If there is more than one direction, remove backtracking choice
        if (oldestBacktrack != null && oldestBacktrack.size() != 0) {
            if (possibleMoves.size() > 2) {
                for (Directions d : oldestBacktrack) {
                    possibleMoves.remove(d);
                }
                
            } else if (possibleMoves.size() > 1) {
                if (oldestBacktrack.size() > 1) {
                    // If possibleMoves has both of backtrack directions, remove latest one
                    if (possibleMoves.contains(oldestBacktrack.get(1)) && 
                    possibleMoves.contains(oldestBacktrack.get(oldestBacktrack.size()-1))) {
                        possibleMoves.remove(oldestBacktrack.get(oldestBacktrack.size()-1));
                    } else {
                        possibleMoves.remove(oldestBacktrack.get(0));
                        possibleMoves.remove(oldestBacktrack.get(oldestBacktrack.size()-1));
                    }
                    
                } else {
                    possibleMoves.remove(oldestBacktrack.get(0));
                }
                
            }
        }

        if (!isFrightened) {
            
            // Update mode count
            this.countMode();
            int[] currentTarget = findCurrentTarget(waka, chaser);

            if (possibleMoves == null || possibleMoves.size() == 0) {
                // If no choice, stop
                this.clearSpeed();
            } else {
                // Move according to target
                // Cell position of current target
                

                
                // Find closest distance
                double closestDistance = -1;
                Directions closestDirection = null;
                for (Directions d : possibleMoves) {
                    // Get ghost distance
                    double otherX = d.getXPos(this.cell);
                    double otherY = d.getYPos(this.cell);
                    double distance = hypot(otherX - currentTarget[0], otherY - currentTarget[1]);
                    
                    if (distance < closestDistance || closestDistance < 0) {
                        closestDistance = distance;
                        closestDirection = d;
                    }
                }

                // Proceed in closest direction
                this.moveFromString(closestDirection);

                // Get new bactrack to see if direction has changed;
                newBacktrack = backtrackVelocityDirection();
            }
            
    
        } else {
            // Is frightened so move randomly
            // If there is only one choice (go backwards)
            if (possibleMoves == null || possibleMoves.size() == 0) {
                // If there are no moves, change speed to 0
                this.clearSpeed();
                // Set current target to itself
                this.currentTarget = this.getCell();
            } else {
                double random = Math.random() * possibleMoves.size();
                int index = (int) random;
                Directions d = possibleMoves.get(index);
                this.moveFromString(possibleMoves.get(index));
                
                // Set current target to the next cell its heading
                int[] nextCell = new int[] {d.getXPos(this.getCell()), d.getYPos(this.getCell())};
                this.currentTarget = nextCell;
            }

            newBacktrack = backtrackVelocityDirection();

            // update frightened countdown
            checkFrightened();

        }

        move(boardObjects);

        // If direction has changed, move waka to center of cell
        if (oldestBacktrack != null && oldestBacktrack.size() != 0 && 
        oldestBacktrack.get(oldestBacktrack.size()-1) != newBacktrack 
        && newBacktrack != null) {
            // If new velocity is right or left, change xpos to middle of cell
            if (newBacktrack == Directions.LEFT || newBacktrack == Directions.RIGHT) {
                this.xpos = this.getCell()[0] * 16 - 5;
            } else {
                // Changed ypos to middle of cell
                this.ypos = this.getCell()[1] * 16 - 5;
            }
            updateCenterPoint();
        }

    }

    /**
     * If it is in scatter mode, return it's default target. Else find it's target based off
     * waka's position.
     * @param waka Waka
     * @param chaser Chaser
     * @return the cell position of it's current target.
     */
    public int[] findCurrentTarget(Waka waka, Ghost chaser) {
        if (isScatter) {
            this.currentTarget = targetDefault;
        } else {
            this.currentTarget = updateTarget(waka, chaser);
        }

        return this.currentTarget;
    }

    /**
     * @return return ghost's current target
     */
    public int[] getCurrentTarget() {
        return this.currentTarget;
    }

    /**
     * From the enum direction, correctly change the speed
     * @param direction Enum direction
     */
    public void moveFromString(Directions direction) {
        // change velocity based off directions
        if (direction == Directions.DOWN) {
            down();
        } else if (direction == Directions.UP) {
            up();
        } else if (direction == Directions.LEFT) {
            left();
        } else if (direction == Directions.RIGHT) {
            right();
        }
    }

    /**
     * From the ghost's current velocity, get the equivalent backtrack direction
     * @return backtrack direction
     */
    public Directions backtrackVelocityDirection() {
        // Return Directions equivalent of integer velocity backtrack
        if (dx > 0) {
            return Directions.UP;
        } else if (dx < 0) {
            return Directions.DOWN;
        } else if (dy > 0) {
            return Directions.LEFT;
        } else if (dy < 0) {
            return Directions.RIGHT;
        }

        return null;
    }

    /**
     * Find the possible directions the ghost can take
     * @param boardObjects Item array of board objects
     * @return List of Directions
     */
    public ArrayList<Directions> findPossibleMoves(Item[][] boardObjects) {
        ArrayList<Directions> posMoves = new ArrayList<>();

        // Add free directions to the list
        if (checkUp(boardObjects)) {
            posMoves.add(Directions.UP);
        }
        if (checkDown(boardObjects)) {
            posMoves.add(Directions.DOWN);
        }
        if (checkLeft(boardObjects)) {
            posMoves.add(Directions.LEFT);
        }
        if (checkRight(boardObjects)) {
            posMoves.add(Directions.RIGHT);
        }

        return posMoves;
    }


    /**
     * Get the ghost's target based off the waka's location
     * @param waka
     * @param chaser
     * @return cell coordinates of target
     */
    public abstract int[] updateTarget(Waka waka, Ghost chaser);


}